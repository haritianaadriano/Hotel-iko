'use strict';


/**
 * Delete a Country by Id
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.deleteCountryById = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a list of Country
 *
 * returns List
 **/
exports.getCountry = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "countryName" : "Antananarivo",
  "idCountry" : 1
}, {
  "countryName" : "Antananarivo",
  "idCountry" : 1
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Change Country by Id
 * Multiple status values can be provIded with comma separated strings
 *
 * id Integer 
 * country_name String 
 * returns Country
 **/
exports.putCountryById = function(id,country_name) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "countryName" : "Antananarivo",
  "idCountry" : 1
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

