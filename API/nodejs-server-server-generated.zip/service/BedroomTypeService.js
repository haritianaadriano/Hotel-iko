'use strict';


/**
 * Delete a bedroom_type by Id
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.delete bedroom_type by id = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a list of bedroom_type
 *
 * returns List
 **/
exports.getBedroom_type = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "idBedroomType" : 1,
  "bedroomType" : "Large"
}, {
  "idBedroomType" : 1,
  "bedroomType" : "Large"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Change bedroom_type by Id
 * change bedroom_type type
 *
 * id Integer 
 * bedroom_type String 
 * returns Bedroom_type
 **/
exports.putBedroomType = function(id,bedroom_type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "idBedroomType" : 1,
  "bedroomType" : "Large"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

