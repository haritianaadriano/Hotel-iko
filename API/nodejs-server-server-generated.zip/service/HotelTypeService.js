'use strict';


/**
 * Delete a hotel_type by Id
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.delete hotel_type by id = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a list of hotels_type
 *
 * returns List
 **/
exports.getHotelType = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "idHotel" : 1,
  "hotelType" : "Luxe"
}, {
  "idHotel" : 1,
  "hotelType" : "Luxe"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Change hotel_type by Id
 * change hotel_type type
 *
 * id Integer 
 * hotel_type String 
 * returns Hotel_type
 **/
exports.putHotelType = function(id,hotel_type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "idHotel" : 1,
  "hotelType" : "Luxe"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

