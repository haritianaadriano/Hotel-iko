'use strict';


/**
 * Add a new \"Bedroom\"
 *
 * body List This request is use to add a new "Bedroom"
 * returns List
 **/
exports.addBedRoom = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 50000,
  "typeBedroom" : "1lit",
  "hotel" : "Novotel"
}, {
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 50000,
  "typeBedroom" : "1lit",
  "hotel" : "Novotel"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete \"Bedroom\" by Id
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.deleteBedroom = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a list of \"Bedroom\"
 *
 * returns List
 **/
exports.getBedroom = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 50000,
  "typeBedroom" : "1lit",
  "hotel" : "Novotel"
}, {
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 50000,
  "typeBedroom" : "1lit",
  "hotel" : "Novotel"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * get bedrooms by hotel
 *
 * returns List
 **/
exports.getBedroomByHotel = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "country" : "Alarobia",
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 4500000,
  "typeBedroom" : "Large",
  "hotel" : "Novotel"
}, {
  "country" : "Alarobia",
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 4500000,
  "typeBedroom" : "Large",
  "hotel" : "Novotel"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Change some details of \"Bedroom\" by Id
 *
 * body CreateBedroom  (optional)
 * id Integer 
 * returns Bedroom
 **/
exports.pathBedroomById = function(body,id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "typeLogement" : "VIP",
  "IdBedroom" : 1,
  "prixLogement" : 50000,
  "typeBedroom" : "1lit",
  "hotel" : "Novotel"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

