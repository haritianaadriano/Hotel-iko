'use strict';


/**
 * Add a new Customer
 *
 * body List Customer object that needs to be added
 * returns List
 **/
exports.addCustomer = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "Id" : 1,
  "email" : "hei.adriano.4@gmail.com"
}, {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "Id" : 1,
  "email" : "hei.adriano.4@gmail.com"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete a Customer by Id
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.deleteCustomerId = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get specific Customer by Id or by name
 *
 * id Integer 
 * name String  (optional)
 * last_name String  (optional)
 * returns List
 **/
exports.get customer by Id or name = function(id,name,last_name) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "Id" : 1,
  "email" : "hei.adriano.4@gmail.com"
}, {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "Id" : 1,
  "email" : "hei.adriano.4@gmail.com"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get a list of Customer
 *
 * returns List
 **/
exports.getCustomer = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "Id" : 1,
  "email" : "hei.adriano.4@gmail.com"
}, {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "Id" : 1,
  "email" : "hei.adriano.4@gmail.com"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Change Customer by Id
 * Multiple status values can be provIded with comma separated strings
 *
 * id Long 
 * name String  (optional)
 * last_name String  (optional)
 * returns List
 **/
exports.putCustomerId = function(id,name,last_name) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "email" : "hei.adriano.4@gmail.com"
}, {
  "lastName" : "adriano",
  "phone" : "+261 34 76 765 58",
  "name" : "haritiana",
  "email" : "hei.adriano.4@gmail.com"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Modifie some customer details
 *
 * body List  (optional)
 * id Integer 
 * no response value expected for this operation
 **/
exports.updateCustomer = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

