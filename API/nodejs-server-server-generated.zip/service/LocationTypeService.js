'use strict';


/**
 * Delete a location_type by Id
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.delete location_type by id = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a list of location_type
 *
 * returns List
 **/
exports.getLocationType = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "idHotel" : 1,
  "hotelType" : "Luxe"
}, {
  "idHotel" : 1,
  "hotelType" : "Luxe"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Change location_type by Id
 * change location_type
 *
 * id Integer 
 * location_type String 
 * returns Location_type
 **/
exports.putLocationType = function(id,location_type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "idLocationType" : 1,
  "locationType" : "VIP"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

