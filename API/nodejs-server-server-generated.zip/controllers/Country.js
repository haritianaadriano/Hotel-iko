'use strict';

var utils = require('../utils/writer.js');
var Country = require('../service/CountryService');

module.exports.deleteCountryById = function deleteCountryById (req, res, next, id) {
  Country.deleteCountryById(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getCountry = function getCountry (req, res, next) {
  Country.getCountry()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putCountryById = function putCountryById (req, res, next, id, country_name) {
  Country.putCountryById(id, country_name)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
