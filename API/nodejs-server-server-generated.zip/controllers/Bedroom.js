'use strict';

var utils = require('../utils/writer.js');
var Bedroom = require('../service/BedroomService');

module.exports.addBedRoom = function addBedRoom (req, res, next, body) {
  Bedroom.addBedRoom(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteBedroom = function deleteBedroom (req, res, next, id) {
  Bedroom.deleteBedroom(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBedroom = function getBedroom (req, res, next) {
  Bedroom.getBedroom()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBedroomByHotel = function getBedroomByHotel (req, res, next) {
  Bedroom.getBedroomByHotel()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.pathBedroomById = function pathBedroomById (req, res, next, body, id) {
  Bedroom.pathBedroomById(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
