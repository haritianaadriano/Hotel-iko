'use strict';

var utils = require('../utils/writer.js');
var HotelType = require('../service/HotelTypeService');

module.exports.delete hotel_type by id = function delete hotel_type by id (req, res, next, id) {
  HotelType.delete hotel_type by id(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getHotelType = function getHotelType (req, res, next) {
  HotelType.getHotelType()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putHotelType = function putHotelType (req, res, next, id, hotel_type) {
  HotelType.putHotelType(id, hotel_type)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
