'use strict';

var utils = require('../utils/writer.js');
var LocationType = require('../service/LocationTypeService');

module.exports.delete location_type by id = function delete location_type by id (req, res, next, id) {
  LocationType.delete location_type by id(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getLocationType = function getLocationType (req, res, next) {
  LocationType.getLocationType()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putLocationType = function putLocationType (req, res, next, id, location_type) {
  LocationType.putLocationType(id, location_type)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
