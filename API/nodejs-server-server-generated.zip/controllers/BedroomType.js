'use strict';

var utils = require('../utils/writer.js');
var BedroomType = require('../service/BedroomTypeService');

module.exports.delete bedroom_type by id = function delete bedroom_type by id (req, res, next, id) {
  BedroomType.delete bedroom_type by id(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBedroom_type = function getBedroom_type (req, res, next) {
  BedroomType.getBedroom_type()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putBedroomType = function putBedroomType (req, res, next, id, bedroom_type) {
  BedroomType.putBedroomType(id, bedroom_type)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
